# BookShelf.pk — Premium Online Bookstore

A beautiful, feature-rich online bookstore inspired by book-shelf.pk, built with Vite + React + TypeScript + Tailwind CSS.

## Features

- 🚀 **Spatial Parallax Hero** — Stunning animated hero section with scroll-driven animations
- 📚 **Real Book Data** — Powered by the Open Library API (openlibrary.org) with 1M+ books
- 🖼️ **Real Cover Images** — High-quality book covers from covers.openlibrary.org
- 🛒 **Shopping Cart** — Full cart with quantity controls and checkout flow
- ❤️ **Wishlist** — Save books for later
- 🔍 **Live Search** — Search any book with instant results in a right sidebar
- 👤 **Login / Register** — Auth panel with account management
- 💬 **AI Chatbot** — Smart book recommendation chatbot
- 📖 **Book Detail Pages** — Full detail with reviews, format selection, and recommendations
- 🎯 **Hover Mega Menus** — Rich dropdown navigation for Books and Categories
- 📱 **Fully Responsive** — Works on mobile, tablet, and desktop

## Tech Stack

- **Vite** — Lightning fast dev server and builds
- **React 18** — Modern React with hooks
- **TypeScript** — Full type safety
- **Tailwind CSS v4** — Utility-first styling
- **Framer Motion** — Smooth animations
- **TanStack React Query** — Data fetching and caching
- **Wouter** — Lightweight client-side routing
- **Open Library API** — Free, open book database

## Getting Started

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

The app runs at http://localhost:5173

## Project Structure

```
src/
├── components/
│   ├── Navbar.tsx       — Navigation with mega menus + right sidebars
│   ├── Hero.tsx         — Spatial parallax hero section
│   ├── BookCard.tsx     — Reusable book card component
│   ├── BookSection.tsx  — Scrollable book section with skeleton loading
│   ├── RightPanel.tsx   — Cart, Search, Login, Wishlist sidebars
│   └── Chatbot.tsx      — Book recommendation chatbot
├── pages/
│   ├── Home.tsx         — Full home page with all sections
│   ├── BookDetail.tsx   — Book detail with reviews + recommendations
│   └── not-found.tsx    — 404 page
├── lib/
│   ├── api.ts           — Open Library API integration
│   └── context.tsx      — Cart, Wishlist, Auth, Panel state
├── App.tsx              — Root app with router and providers
├── main.tsx             — Entry point
└── index.css            — Global styles and theme
```

## API

Uses the free **Open Library API** — no API key required:
- Search: `https://openlibrary.org/search.json`
- Covers: `https://covers.openlibrary.org/b/id/{id}-L.jpg`
- Works: `https://openlibrary.org/works/{key}.json`
