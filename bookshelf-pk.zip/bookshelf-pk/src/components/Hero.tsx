import { useEffect, useRef, useState, type MouseEvent } from "react";
import { Link } from "wouter";
import { usePanel } from "@/lib/context";
import type { Book } from "@/lib/api";

interface Props {
  featuredBooks: Book[];
}

export default function Hero({ featuredBooks }: Props) {
  const bgRef = useRef<HTMLDivElement>(null);
  const { open } = usePanel();
  const [imgErrors, setImgErrors] = useState<Record<number, boolean>>({});

  useEffect(() => {
    const updateParallax = () => {
      const progress = Math.min(window.scrollY / (window.innerHeight * 1.2), 1);
      if (bgRef.current) {
        bgRef.current.style.transform = `translateY(${progress * -8}vh) scale(${1 + progress * 0.06})`;
      }
    };
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = window.requestAnimationFrame(() => { updateParallax(); raf = 0; });
    };
    updateParallax();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", updateParallax);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", updateParallax); };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in-view"); observer.unobserve(e.target); } }),
      { threshold: 0.1 }
    );
    document.querySelectorAll("[data-reveal]").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [featuredBooks]);

  const handleMove = (e: MouseEvent<HTMLButtonElement>) => {
    const t = e.currentTarget;
    const r = t.getBoundingClientRect();
    t.style.setProperty("--x", `${e.clientX - r.left}px`);
    t.style.setProperty("--y", `${e.clientY - r.top}px`);
  };

  const displayBooks = featuredBooks.slice(0, 5);
  const heroBook = displayBooks[0];

  return (
    <div
      className="relative min-h-screen overflow-hidden bg-[var(--bs-cream)] text-foreground antialiased"
      style={{ background: "linear-gradient(135deg, #FAF8F5 0%, #F5EEE6 40%, #EDE3D9 100%)" }}
    >
      {/* Background book grid — right side parallax */}
      <div className="hero-bg-anchor">
        <div ref={bgRef} className="w-full h-full" style={{ transformOrigin: "center center", willChange: "transform" }}>
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(135deg, #EDE3D9 0%, #D4C5B0 50%, #C4A882 100%)",
            }}
          />
          <div className="absolute inset-0 grid grid-cols-3 gap-3 p-6 rotate-3" style={{ transform: "rotate(3deg) scale(1.15)" }}>
            {displayBooks.map((book, idx) => (
              <Link key={book.key} href={`/book/${book.workKey}`}
                className={`overflow-hidden rounded-xl shadow-lg transition-transform hover:scale-105 ${idx === 0 ? "col-span-2 row-span-2" : ""}`}
                style={{ opacity: 0.9 }}
              >
                <img
                  src={imgErrors[idx] ? `https://placehold.co/200x300/6B1B1B/FAF8F5?text=${encodeURIComponent(book.title.slice(0,15))}` : book.coverUrl}
                  alt={book.title}
                  onError={() => setImgErrors(prev => ({ ...prev, [idx]: true }))}
                  className="w-full h-full object-cover"
                />
              </Link>
            ))}
          </div>
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-[#FAF8F5]/90" />
        </div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.25)_0%,transparent_50%)] mix-blend-soft-light" />
      </div>

      {/* Main content */}
      <main className="fractal-container relative z-10 grid min-h-screen grid-cols-12 gap-4 px-4 pt-24 pb-12 md:px-12 lg:px-20"
        style={{ minHeight: "100vh" }}>

        {/* Left: Headline */}
        <header className="z-plane-1 col-span-12 md:col-span-7 flex flex-col justify-center mt-8 md:mt-0">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[var(--bs-burgundy)] mb-4 opacity-80">
            Pakistan's Premier Bookstore
          </p>
          <h1 className="gradient-text pb-3 text-5xl md:text-7xl lg:text-8xl font-light leading-[0.9] tracking-tighter">
            Discover
            <br />
            Your Next
            <br />
            <em style={{ fontStyle: "italic", fontWeight: 600 }}>Story.</em>
          </h1>
          <p className="mt-8 max-w-md text-lg font-light leading-relaxed text-foreground/60">
            Over a million books, curated for every reader. Fiction, non-fiction, classics, and contemporary — all delivered to your door.
          </p>

          <div className="flex flex-wrap gap-4 mt-10">
            <button
              onMouseMove={handleMove}
              onClick={() => open("search")}
              data-testid="btn-hero-explore"
              className="liquid-mercury-btn rounded-full px-8 py-4 text-sm font-semibold tracking-wide"
            >
              Explore Books
            </button>
            <Link href={heroBook ? `/book/${heroBook.workKey}` : "/"}
              data-testid="link-hero-featured"
              className="rounded-full px-8 py-4 text-sm font-semibold tracking-wide border-2 border-[var(--bs-burgundy)] text-[var(--bs-burgundy)] hover:bg-[var(--bs-burgundy)] hover:text-white transition-all duration-300">
              Featured Pick
            </Link>
          </div>

          {/* Stats */}
          <div className="flex gap-8 mt-12">
            {[
              { label: "Books Available", value: "1M+" },
              { label: "Happy Readers", value: "50K+" },
              { label: "Genres", value: "200+" },
            ].map((s) => (
              <div key={s.label}>
                <p className="font-serif text-2xl font-bold gradient-text">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </header>

        {/* Right: Featured book card */}
        {heroBook && (
          <div className="z-plane-2 relative col-span-12 md:col-start-9 md:col-span-4 flex items-center mt-12 md:mt-0">
            <div data-reveal className="sculpted-volume w-full p-6 opacity-0">
              <div className="flex items-start justify-between mb-4">
                <span className="text-xs uppercase tracking-[0.25em] opacity-50">Featured Pick</span>
                <div className="h-2 w-2 rounded-full bg-[var(--bs-burgundy)] shadow-[0_0_10px_var(--bs-burgundy)]" />
              </div>
              <Link href={`/book/${heroBook.workKey}`} className="block mb-4 group" data-testid="link-hero-book-cover">
                <div className="relative overflow-hidden rounded-xl shadow-xl aspect-[2/3] max-h-64">
                  <img
                    src={imgErrors[-1] ? `https://placehold.co/200x300/6B1B1B/FAF8F5?text=${encodeURIComponent(heroBook.title.slice(0,15))}` : heroBook.coverUrl}
                    alt={heroBook.title}
                    onError={() => setImgErrors(prev => ({ ...prev, [-1]: true }))}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
              </Link>
              <h2 className="font-serif text-xl font-semibold leading-tight line-clamp-2">{heroBook.title}</h2>
              <p className="text-sm opacity-60 mt-1 mb-3">{heroBook.author}</p>
              <div className="flex items-end justify-between">
                <div>
                  <span className="text-xl font-bold text-[var(--bs-burgundy)]">${heroBook.price}</span>
                  <span className="text-sm line-through text-muted-foreground ml-2">${heroBook.originalPrice}</span>
                </div>
                <button onMouseMove={handleMove}
                  onClick={(e) => { e.preventDefault(); }}
                  data-testid="btn-hero-book-cta"
                  className="liquid-mercury-btn rounded-full px-5 py-2.5 text-xs font-semibold">
                  Buy Now
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Bottom floating cards */}
        {displayBooks[1] && (
          <div className="z-plane-1 col-span-6 md:col-span-3 mt-4 md:mt-0">
            <div data-reveal className="sculpted-volume p-4 opacity-0 flex items-center gap-3">
              <Link href={`/book/${displayBooks[1].workKey}`} className="shrink-0">
                <div className="h-16 w-12 overflow-hidden rounded-lg shadow-md">
                  <img src={displayBooks[1].coverUrl} alt={displayBooks[1].title}
                    className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = `https://placehold.co/200x300/6B1B1B/FAF8F5?text=Book`; }} />
                </div>
              </Link>
              <div className="min-w-0">
                <p className="text-xs font-semibold line-clamp-2 leading-tight">{displayBooks[1].title}</p>
                <p className="text-[11px] opacity-50 mt-0.5">{displayBooks[1].author}</p>
                <p className="text-sm font-bold text-[var(--bs-burgundy)] mt-1">${displayBooks[1].price}</p>
              </div>
            </div>
          </div>
        )}

        {displayBooks[2] && (
          <div className="z-plane-2 col-span-6 md:col-span-3 mt-4 md:mt-0">
            <div data-reveal className="sculpted-volume p-4 opacity-0 flex items-center gap-3">
              <Link href={`/book/${displayBooks[2].workKey}`} className="shrink-0">
                <div className="h-16 w-12 overflow-hidden rounded-lg shadow-md">
                  <img src={displayBooks[2].coverUrl} alt={displayBooks[2].title}
                    className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = `https://placehold.co/200x300/6B1B1B/FAF8F5?text=Book`; }} />
                </div>
              </Link>
              <div className="min-w-0">
                <p className="text-xs font-semibold line-clamp-2 leading-tight">{displayBooks[2].title}</p>
                <p className="text-[11px] opacity-50 mt-0.5">{displayBooks[2].author}</p>
                <p className="text-sm font-bold text-[var(--bs-burgundy)] mt-1">${displayBooks[2].price}</p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 z-10">
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <div className="w-px h-10 bg-foreground animate-pulse" />
      </div>
    </div>
  );
}
