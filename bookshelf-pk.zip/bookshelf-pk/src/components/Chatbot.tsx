import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { searchBooks, type Book } from "@/lib/api";
import { Link } from "wouter";

interface Message {
  id: string;
  role: "bot" | "user";
  text: string;
  books?: Book[];
}

const GREET = `Hi! I'm your BookShelf assistant 📚

I can help you:
• Find books by title, author, or genre
• Get book recommendations
• Answer questions about our store

What are you looking for today?`;

const QUICK_REPLIES = ["Recommend a novel", "Best sellers", "Urdu books", "Help with order"];

function getBotResponse(text: string): string | null {
  const lower = text.toLowerCase();
  if (lower.match(/\b(hello|hi|hey|salaam|helo)\b/)) return "Salaam! 👋 How can I help you find your next great read?";
  if (lower.match(/\b(thanks|thank you|shukria)\b/)) return "You're most welcome! Happy reading! 📖";
  if (lower.match(/\b(price|cost|how much|rate)\b/)) return "Our books are priced from $12 to $65. We offer free shipping on all orders! 🚚";
  if (lower.match(/\b(deliver|shipping|ship)\b/)) return "We offer FREE shipping on all orders across Pakistan. Delivery takes 3-5 business days. 📦";
  if (lower.match(/\b(return|refund|exchange)\b/)) return "We have a hassle-free 7-day return policy. Books must be in original condition. 📋";
  if (lower.match(/\b(pay|payment|cash|cod|online)\b/)) return "We accept Cash on Delivery (COD), Bank Transfer, EasyPaisa, JazzCash, and all major credit cards. 💳";
  if (lower.match(/\b(help|support|contact)\b/)) return "You can reach us at support@bookshelf.pk or call +92-300-0000000. We're available Mon-Sat 9am-6pm. 📞";
  if (lower.match(/\b(order|track|status)\b/)) return "To track your order, visit our Order Tracking page or email us your order number at orders@bookshelf.pk. 🔍";
  if (lower.match(/\b(best\s*seller|popular|trending)\b/)) return null; // trigger search
  if (lower.match(/\b(recommend|suggest|good book|what to read)\b/)) return null; // trigger search
  return null;
}

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: "0", role: "bot", text: GREET },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const addMessage = (msg: Omit<Message, "id">) => {
    setMessages((prev) => [...prev, { ...msg, id: Date.now().toString() + Math.random() }]);
  };

  const handleSend = async (text: string) => {
    const t = text.trim();
    if (!t || loading) return;
    setInput("");
    addMessage({ role: "user", text: t });
    setLoading(true);

    await new Promise((r) => setTimeout(r, 500));

    const staticReply = getBotResponse(t);

    if (staticReply !== null) {
      addMessage({ role: "bot", text: staticReply });
      setLoading(false);
      return;
    }

    // Search for books
    try {
      const lower = t.toLowerCase();
      let query = t;
      if (lower.includes("recommend") || lower.includes("suggest")) {
        query = "popular fiction bestseller";
      } else if (lower.includes("best seller") || lower.includes("bestseller") || lower.includes("trending")) {
        query = "bestseller fiction";
      } else if (lower.includes("urdu")) {
        query = "urdu literature";
      }

      const books = await searchBooks(query, 4);

      if (books.length === 0) {
        addMessage({ role: "bot", text: `I couldn't find books matching "${t}". Try searching with different keywords, or browse our categories!` });
      } else {
        addMessage({
          role: "bot",
          text: `Here are some books matching "${t}" 📚`,
          books: books.slice(0, 4),
        });
      }
    } catch {
      addMessage({ role: "bot", text: "Sorry, I'm having trouble searching right now. Please try again in a moment!" });
    }
    setLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(input); }
  };

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={() => setOpen((v) => !v)}
        data-testid="btn-chatbot-toggle"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex items-center justify-center"
        style={{ boxShadow: "0 8px 32px rgba(107,27,27,0.35)" }}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X size={22} />
            </motion.div>
          ) : (
            <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <MessageCircle size={22} />
            </motion.div>
          )}
        </AnimatePresence>
      </button>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-background rounded-2xl shadow-2xl border border-border overflow-hidden flex flex-col"
            style={{ height: 480, boxShadow: "0 20px 70px rgba(0,0,0,0.18)" }}
            data-testid="chatbot-window"
          >
            {/* Header */}
            <div className="flex items-center gap-3 p-4 bg-primary text-primary-foreground shrink-0">
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center">
                <Bot size={18} />
              </div>
              <div>
                <p className="font-semibold text-sm">BookShelf Assistant</p>
                <p className="text-xs opacity-75">Online • Ready to help</p>
              </div>
              <div className="ml-auto w-2 h-2 rounded-full bg-green-400 shadow-sm" />
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="chatbot-messages">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  <div className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-xs ${msg.role === "bot" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                    {msg.role === "bot" ? <Bot size={14} /> : <User size={14} />}
                  </div>
                  <div className={`max-w-[80%] ${msg.role === "user" ? "chat-bubble-out" : "chat-bubble-in"}`}>
                    <div className={`px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${msg.role === "bot" ? "bg-muted text-foreground rounded-tl-sm" : "bg-primary text-primary-foreground rounded-tr-sm"}`}>
                      {msg.text}
                    </div>
                    {msg.books && msg.books.length > 0 && (
                      <div className="mt-2 space-y-2">
                        {msg.books.map((book) => (
                          <Link key={book.key} href={`/book/${book.workKey}`} onClick={() => setOpen(false)}
                            className="flex gap-2 p-2 bg-muted rounded-xl hover:bg-primary/5 transition-colors block" data-testid={`chatbot-book-${book.workKey}`}>
                            <img src={book.coverUrl} alt={book.title}
                              className="w-10 h-14 object-cover rounded-lg shrink-0 shadow-sm"
                              onError={(e) => { (e.target as HTMLImageElement).src = `https://placehold.co/200x300/6B1B1B/FAF8F5?text=Book`; }} />
                            <div className="min-w-0">
                              <p className="font-semibold text-xs leading-tight line-clamp-2">{book.title}</p>
                              <p className="text-[11px] text-muted-foreground mt-0.5">{book.author}</p>
                              <p className="text-xs font-bold text-primary mt-1">${book.price}</p>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex gap-2">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0"><Bot size={14} className="text-primary" /></div>
                  <div className="px-4 py-3 bg-muted rounded-2xl rounded-tl-sm flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <span key={i} className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick replies */}
            {messages.length <= 2 && (
              <div className="px-4 pb-2 flex gap-2 flex-wrap shrink-0">
                {QUICK_REPLIES.map((q) => (
                  <button key={q} onClick={() => handleSend(q)}
                    className="text-xs px-3 py-1.5 rounded-full border border-border hover:border-primary hover:text-primary transition-colors bg-muted/50">
                    {q}
                  </button>
                ))}
              </div>
            )}

            {/* Input */}
            <div className="p-3 border-t border-border shrink-0">
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask me about books…"
                  data-testid="input-chatbot"
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-border bg-muted/50 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all"
                />
                <button onClick={() => handleSend(input)} disabled={!input.trim() || loading}
                  data-testid="btn-chatbot-send"
                  className="p-2.5 rounded-xl bg-primary text-primary-foreground disabled:opacity-40 hover:bg-primary/90 transition-all">
                  <Send size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
