import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { Search, User, ShoppingCart, Heart, BookOpen, Menu, X, ChevronDown } from "lucide-react";
import { usePanel, useCart, useWishlist } from "@/lib/context";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORIES = [
  { label: "Fiction", sub: ["Literary Fiction", "Historical Fiction", "Sci-Fi", "Fantasy", "Horror", "Thriller"] },
  { label: "Non-Fiction", sub: ["Biography", "Self-Help", "True Crime", "Science", "Travel", "Food & Cooking"] },
  { label: "Academic", sub: ["Engineering", "Medicine", "Law", "Business", "Psychology", "Mathematics"] },
  { label: "Children", sub: ["Picture Books", "Early Readers", "Middle Grade", "Young Adult", "Educational", "Classic Tales"] },
];

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Books", href: "/books", dropdown: true },
  { label: "Categories", href: "/categories", dropdown: true },
  { label: "New Arrivals", href: "/new-arrivals" },
  { label: "Bestsellers", href: "/bestsellers" },
  { label: "About", href: "/about" },
];

export default function Navbar() {
  const [location] = useLocation();
  const { open, panel } = usePanel();
  const { count } = useCart();
  const wishlist = useWishlist();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setActiveDropdown(null);
  }, [location]);

  const handleMouseEnter = (label: string, hasDropdown?: boolean) => {
    if (!hasDropdown) return;
    clearTimeout(timerRef.current);
    setActiveDropdown(label);
  };

  const handleMouseLeave = () => {
    timerRef.current = setTimeout(() => setActiveDropdown(null), 120);
  };

  const keepOpen = () => clearTimeout(timerRef.current);

  const getDropdownContent = (label: string) => {
    if (label === "Books") {
      return (
        <div className="grid grid-cols-4 gap-8 p-8">
          {CATEGORIES.map((cat) => (
            <div key={cat.label}>
              <h4 className="font-serif font-bold text-sm text-foreground mb-3 pb-2 border-b border-border">{cat.label}</h4>
              <ul className="space-y-2">
                {cat.sub.map((s) => (
                  <li key={s}>
                    <span className="text-sm text-muted-foreground hover:text-primary cursor-pointer transition-colors duration-150">
                      {s}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div className="col-span-4 pt-4 border-t border-border mt-2 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">Discover 1M+ books across all genres</p>
            <button onClick={() => open("search")}
              className="text-sm font-semibold text-primary hover:underline">
              Search all books →
            </button>
          </div>
        </div>
      );
    }
    if (label === "Categories") {
      return (
        <div className="grid grid-cols-3 gap-6 p-8">
          {[
            { name: "Fiction", icon: "📖", count: "250K+" },
            { name: "Non-Fiction", icon: "📚", count: "180K+" },
            { name: "Mystery & Thriller", icon: "🔍", count: "95K+" },
            { name: "Romance", icon: "💌", count: "130K+" },
            { name: "Science Fiction", icon: "🚀", count: "78K+" },
            { name: "Biography", icon: "👤", count: "65K+" },
            { name: "Self-Help", icon: "🌱", count: "88K+" },
            { name: "Children", icon: "🎈", count: "120K+" },
            { name: "Academic", icon: "🎓", count: "200K+" },
          ].map((cat) => (
            <button key={cat.name} onClick={() => open("search")}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-primary/5 transition-colors text-left group">
              <span className="text-2xl">{cat.icon}</span>
              <div>
                <p className="font-medium text-sm group-hover:text-primary transition-colors">{cat.name}</p>
                <p className="text-xs text-muted-foreground">{cat.count} books</p>
              </div>
            </button>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
          scrolled
            ? "bg-background/95 backdrop-blur-xl shadow-md border-b border-border/50"
            : "bg-transparent"
        }`}
        data-testid="navbar"
      >
        <div className="max-w-screen-xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 group" data-testid="link-logo">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
                <BookOpen size={18} className="text-primary-foreground" />
              </div>
              <div>
                <span className="font-serif text-xl font-bold text-foreground leading-none block">BookShelf</span>
                <span className="text-[10px] text-muted-foreground tracking-widest uppercase leading-none">.pk</span>
              </div>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-1" ref={dropdownRef}>
              {NAV_LINKS.map((link) => (
                <div key={link.label} className="relative"
                  onMouseEnter={() => handleMouseEnter(link.label, link.dropdown)}
                  onMouseLeave={handleMouseLeave}>
                  <Link href={link.href}
                    data-testid={`nav-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                    className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 group
                      ${location === link.href ? "text-primary bg-primary/8" : "text-foreground/70 hover:text-foreground hover:bg-foreground/5"}`}>
                    {link.label}
                    {link.dropdown && (
                      <ChevronDown size={14} className={`transition-transform duration-200 ${activeDropdown === link.label ? "rotate-180" : ""}`} />
                    )}
                  </Link>
                </div>
              ))}
            </nav>

            {/* Right icons */}
            <div className="flex items-center gap-1">
              {[
                { icon: Search, action: () => open("search"), label: "Search", badge: 0, testId: "btn-nav-search" },
                { icon: User, action: () => open("login"), label: "Account", badge: 0, testId: "btn-nav-account" },
                { icon: Heart, action: () => open("wishlist"), label: "Wishlist", badge: wishlist.items.length, testId: "btn-nav-wishlist" },
                { icon: ShoppingCart, action: () => open("cart"), label: "Cart", badge: count, testId: "btn-nav-cart" },
              ].map(({ icon: Icon, action, label, badge, testId }) => (
                <button key={label} onClick={action} data-testid={testId}
                  className={`relative p-2.5 rounded-xl transition-all duration-200 group
                    ${panel !== null && testId === `btn-nav-${panel === "login" ? "account" : panel}`
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "text-foreground/70 hover:text-foreground hover:bg-foreground/6"}`}
                  title={label}>
                  <Icon size={20} />
                  {badge > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center px-1 shadow-sm">
                      {badge > 9 ? "9+" : badge}
                    </span>
                  )}
                </button>
              ))}

              {/* Mobile menu */}
              <button className="lg:hidden p-2.5 rounded-xl text-foreground/70 hover:text-foreground hover:bg-foreground/6 transition-all ml-1"
                onClick={() => setMobileOpen((v) => !v)} data-testid="btn-mobile-menu">
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Desktop mega-dropdown */}
        <AnimatePresence>
          {activeDropdown && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
              className="absolute top-full left-0 right-0 bg-background border-b border-border shadow-xl z-50"
              onMouseEnter={keepOpen}
              onMouseLeave={handleMouseLeave}
              data-testid="nav-dropdown"
            >
              <div className="max-w-screen-xl mx-auto">
                {getDropdownContent(activeDropdown)}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.22 }}
            className="fixed inset-0 z-40 bg-background pt-20 px-6 lg:hidden overflow-y-auto"
            data-testid="mobile-menu"
          >
            <nav className="flex flex-col gap-1">
              {NAV_LINKS.map((link) => (
                <Link key={link.label} href={link.href}
                  className={`px-4 py-3 rounded-xl text-base font-medium transition-colors
                    ${location === link.href ? "bg-primary/10 text-primary" : "text-foreground hover:bg-muted"}`}>
                  {link.label}
                </Link>
              ))}
              <hr className="my-3 border-border" />
              <button onClick={() => { open("search"); setMobileOpen(false); }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium text-foreground hover:bg-muted transition-colors">
                <Search size={18} /> Search Books
              </button>
              <button onClick={() => { open("login"); setMobileOpen(false); }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium text-foreground hover:bg-muted transition-colors">
                <User size={18} /> My Account
              </button>
              <button onClick={() => { open("wishlist"); setMobileOpen(false); }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium text-foreground hover:bg-muted transition-colors">
                <Heart size={18} /> Wishlist {wishlist.items.length > 0 && `(${wishlist.items.length})`}
              </button>
              <button onClick={() => { open("cart"); setMobileOpen(false); }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium text-foreground hover:bg-muted transition-colors">
                <ShoppingCart size={18} /> Cart {count > 0 && `(${count})`}
              </button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
