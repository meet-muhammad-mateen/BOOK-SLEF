import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import BookCard from "./BookCard";
import type { Book } from "@/lib/api";

interface Props {
  title: string;
  subtitle?: string;
  books: Book[];
  loading?: boolean;
  variant?: "default" | "compact";
}

function SkeletonCard() {
  return (
    <div className="rounded-2xl overflow-hidden border border-border/30 bg-card">
      <div className="skeleton" style={{ aspectRatio: "2/3" }} />
      <div className="p-4 space-y-2">
        <div className="skeleton h-4 rounded w-4/5" />
        <div className="skeleton h-3 rounded w-2/3" />
        <div className="skeleton h-3 rounded w-1/2" />
        <div className="skeleton h-7 rounded-xl w-full mt-2" />
      </div>
    </div>
  );
}

export default function BookSection({ title, subtitle, books, loading = false, variant = "default" }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    if (!scrollRef.current) return;
    const by = 300;
    scrollRef.current.scrollBy({ left: dir === "left" ? -by : by, behavior: "smooth" });
  };

  return (
    <section className="py-12 px-4 md:px-8 lg:px-16 xl:px-24" data-testid={`section-${title.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="flex items-end justify-between mb-8">
        <div>
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground leading-tight">
            {title}
          </h2>
          {subtitle && <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>}
        </div>
        <div className="flex gap-2 shrink-0">
          <button onClick={() => scroll("left")} data-testid="btn-scroll-left"
            className="p-2.5 rounded-xl border border-border hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all shadow-sm">
            <ChevronLeft size={18} />
          </button>
          <button onClick={() => scroll("right")} data-testid="btn-scroll-right"
            className="p-2.5 rounded-xl border border-border hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all shadow-sm">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div ref={scrollRef}
        className="flex gap-5 overflow-x-auto pb-4 scrollbar-none snap-x snap-mandatory"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="shrink-0 snap-start" style={{ width: variant === "compact" ? 180 : 200 }}>
                <SkeletonCard />
              </div>
            ))
          : books.map((book) => (
              <div key={book.key} className="shrink-0 snap-start" style={{ width: variant === "compact" ? 180 : 200 }}>
                <BookCard book={book} variant={variant === "compact" ? "default" : "default"} />
              </div>
            ))}
      </div>
    </section>
  );
}
