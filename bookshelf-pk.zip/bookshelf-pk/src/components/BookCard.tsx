import { useState } from "react";
import { Link } from "wouter";
import { Heart, ShoppingCart, Star } from "lucide-react";
import { useCart, useWishlist } from "@/lib/context";
import type { Book } from "@/lib/api";

interface Props {
  book: Book;
  variant?: "default" | "compact" | "featured";
}

export default function BookCard({ book, variant = "default" }: Props) {
  const { add } = useCart();
  const wishlist = useWishlist();
  const [imgErr, setImgErr] = useState(false);
  const isWishlisted = wishlist.has(book.key);

  const discount = book.coverId
    ? Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100)
    : 0;

  const coverSrc = imgErr
    ? `https://placehold.co/200x300/6B1B1B/FAF8F5?text=${encodeURIComponent(book.title.slice(0, 18))}`
    : book.coverUrl;

  if (variant === "compact") {
    return (
      <div className="book-card flex gap-3 p-3 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-all"
        data-testid={`book-card-compact-${book.workKey}`}>
        <Link href={`/book/${book.workKey}`} className="shrink-0">
          <img src={coverSrc} onError={() => setImgErr(true)} alt={book.title}
            className="w-14 h-20 object-cover rounded-lg book-cover shadow-sm" />
        </Link>
        <div className="min-w-0 flex flex-col justify-between">
          <div>
            <Link href={`/book/${book.workKey}`}>
              <p className="font-serif font-semibold text-sm leading-tight line-clamp-2 hover:text-primary transition-colors">{book.title}</p>
            </Link>
            <p className="text-xs text-muted-foreground mt-0.5 truncate">{book.author}</p>
          </div>
          <div className="flex items-center justify-between mt-1">
            <span className="font-semibold text-primary text-sm">${book.price}</span>
            <button onClick={() => add(book)} data-testid={`btn-add-cart-compact-${book.workKey}`}
              className="p-1.5 rounded-lg bg-primary/10 hover:bg-primary text-primary hover:text-white transition-all">
              <ShoppingCart size={13} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="book-card group relative bg-card rounded-2xl overflow-hidden border border-border/40 hover:border-primary/30 hover:shadow-lg transition-all duration-300"
      data-testid={`book-card-${book.workKey}`}>
      {book.badge && (
        <span className="absolute top-3 left-3 z-10 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary text-primary-foreground shadow-sm">
          {book.badge}
        </span>
      )}
      {discount > 0 && (
        <span className="absolute top-3 right-3 z-10 text-[10px] font-bold px-2 py-0.5 rounded-full bg-accent text-accent-foreground shadow-sm">
          -{discount}%
        </span>
      )}

      <Link href={`/book/${book.workKey}`} data-testid={`link-book-${book.workKey}`}>
        <div className="relative overflow-hidden bg-muted" style={{ aspectRatio: "2/3" }}>
          <img src={coverSrc} onError={() => setImgErr(true)} alt={book.title}
            className="w-full h-full object-cover book-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
      </Link>

      <button onClick={() => wishlist.toggle(book)}
        data-testid={`btn-wishlist-${book.workKey}`}
        className={`absolute top-3 right-3 p-2 rounded-full shadow-md transition-all duration-200 ${isWishlisted ? "bg-rose-500 text-white scale-110" : "bg-white/90 text-gray-600 hover:bg-rose-50 hover:text-rose-500 opacity-0 group-hover:opacity-100"}`}>
        <Heart size={14} fill={isWishlisted ? "currentColor" : "none"} />
      </button>

      <div className="p-4">
        <Link href={`/book/${book.workKey}`}>
          <h3 className="font-serif font-semibold text-sm leading-snug line-clamp-2 hover:text-primary transition-colors mb-1">
            {book.title}
          </h3>
        </Link>
        <p className="text-xs text-muted-foreground mb-2 truncate">{book.author}</p>

        <div className="flex items-center gap-1 mb-3">
          <Star size={11} className="fill-amber-400 text-amber-400" />
          <span className="text-xs font-medium">{book.rating.toFixed(1)}</span>
          <span className="text-xs text-muted-foreground">({book.ratingCount.toLocaleString()})</span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <span className="font-bold text-primary text-base">${book.price}</span>
            {discount > 0 && (
              <span className="text-xs text-muted-foreground line-through ml-1.5">${book.originalPrice}</span>
            )}
          </div>
          <button onClick={() => add(book)}
            data-testid={`btn-add-cart-${book.workKey}`}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 active:scale-95 transition-all shadow-sm hover:shadow-md">
            <ShoppingCart size={12} />
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
