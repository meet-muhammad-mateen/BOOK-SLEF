import { useState, useEffect, useRef } from "react";
import { X, Trash2, Plus, Minus, Heart, ShoppingCart, Search, User, Star, LogIn, LogOut, UserPlus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { usePanel, useCart, useWishlist, useAuth } from "@/lib/context";
import { searchBooks, type Book } from "@/lib/api";
import { Link } from "wouter";
import BookCard from "./BookCard";

export default function RightPanel() {
  const { panel, close } = usePanel();
  const isOpen = panel !== null;

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <>
      {/* Backdrop */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
            onClick={close}
            data-testid="panel-backdrop"
          />
        )}
      </AnimatePresence>

      {/* Slide-in panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-md bg-background shadow-2xl flex flex-col"
            data-testid={`panel-${panel}`}
          >
            {panel === "cart" && <CartPanel />}
            {panel === "search" && <SearchPanel />}
            {panel === "login" && <LoginPanel />}
            {panel === "wishlist" && <WishlistPanel />}
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}

function PanelHeader({ icon: Icon, title }: { icon: React.ElementType; title: string }) {
  const { close } = usePanel();
  return (
    <div className="flex items-center justify-between p-5 border-b border-border shrink-0">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
          <Icon size={18} className="text-primary" />
        </div>
        <h2 className="font-serif text-xl font-bold">{title}</h2>
      </div>
      <button onClick={close} data-testid="btn-panel-close"
        className="p-2 rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
        <X size={20} />
      </button>
    </div>
  );
}

/* ====== CART ====== */
function CartPanel() {
  const { items, total, remove, updateQty } = useCart();
  const { open } = usePanel();
  return (
    <>
      <PanelHeader icon={ShoppingCart} title="Shopping Cart" />
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
            <ShoppingCart size={48} className="text-muted-foreground/40" />
            <div>
              <p className="font-serif text-lg font-semibold">Your cart is empty</p>
              <p className="text-sm text-muted-foreground mt-1">Add some books to get started</p>
            </div>
            <button onClick={() => open("search")}
              className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors">
              Browse Books
            </button>
          </div>
        ) : (
          items.map((item) => (
            <div key={item.key} className="flex gap-3 p-3 bg-muted/40 rounded-xl" data-testid={`cart-item-${item.workKey}`}>
              <Link href={`/book/${item.workKey}`} className="shrink-0">
                <img src={item.coverUrl} alt={item.title}
                  className="w-16 h-22 object-cover rounded-lg shadow-sm"
                  style={{ height: 88 }}
                  onError={(e) => { (e.target as HTMLImageElement).src = `https://placehold.co/200x300/6B1B1B/FAF8F5?text=Book`; }} />
              </Link>
              <div className="flex-1 min-w-0">
                <Link href={`/book/${item.workKey}`}>
                  <p className="font-serif font-semibold text-sm leading-tight line-clamp-2 hover:text-primary transition-colors">{item.title}</p>
                </Link>
                <p className="text-xs text-muted-foreground mt-0.5 mb-2">{item.author}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 border border-border rounded-lg">
                    <button onClick={() => updateQty(item.key, item.qty - 1)}
                      className="p-1.5 hover:bg-muted rounded-l-lg transition-colors" data-testid={`btn-cart-dec-${item.workKey}`}>
                      <Minus size={12} />
                    </button>
                    <span className="text-sm font-medium w-6 text-center">{item.qty}</span>
                    <button onClick={() => updateQty(item.key, item.qty + 1)}
                      className="p-1.5 hover:bg-muted rounded-r-lg transition-colors" data-testid={`btn-cart-inc-${item.workKey}`}>
                      <Plus size={12} />
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-primary">${(item.price * item.qty).toFixed(0)}</span>
                    <button onClick={() => remove(item.key)} data-testid={`btn-cart-remove-${item.workKey}`}
                      className="p-1.5 text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {items.length > 0 && (
        <div className="p-5 border-t border-border shrink-0 space-y-3">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Subtotal ({items.length} items)</span>
            <span className="font-semibold text-foreground">${total.toFixed(0)}</span>
          </div>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Shipping</span>
            <span className="text-green-600 font-medium">Free</span>
          </div>
          <div className="flex justify-between font-bold text-lg">
            <span>Total</span>
            <span className="text-primary">${total.toFixed(0)}</span>
          </div>
          <button className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all shadow-md hover:shadow-lg active:scale-98"
            data-testid="btn-checkout">
            Proceed to Checkout →
          </button>
        </div>
      )}
    </>
  );
}

/* ====== SEARCH ====== */
function SearchPanel() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    clearTimeout(timerRef.current);
    if (!query.trim()) { setResults([]); return; }
    setLoading(true);
    timerRef.current = setTimeout(async () => {
      const r = await searchBooks(query, 12);
      setResults(r);
      setLoading(false);
    }, 450);
    return () => clearTimeout(timerRef.current);
  }, [query]);

  return (
    <>
      <PanelHeader icon={Search} title="Search Books" />
      <div className="p-5 shrink-0">
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title, author, genre…"
            data-testid="input-search"
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-muted/50 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-3">
        {loading && (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex gap-3 p-3 bg-muted/30 rounded-xl animate-pulse">
                <div className="w-12 h-16 bg-muted rounded-lg shrink-0" />
                <div className="flex-1 space-y-2 pt-1">
                  <div className="h-3.5 bg-muted rounded w-3/4" />
                  <div className="h-3 bg-muted rounded w-1/2" />
                  <div className="h-3 bg-muted rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        )}
        {!loading && results.length > 0 && results.map((book) => (
          <BookCard key={book.key} book={book} variant="compact" />
        ))}
        {!loading && query.trim() && results.length === 0 && (
          <div className="text-center py-8">
            <Search size={32} className="text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-medium">No books found</p>
            <p className="text-sm text-muted-foreground mt-1">Try a different search term</p>
          </div>
        )}
        {!query.trim() && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium mb-3">Popular Searches</p>
            {["Harry Potter", "Atomic Habits", "The Alchemist", "1984", "Pride and Prejudice", "Sapiens"].map((q) => (
              <button key={q} onClick={() => setQuery(q)}
                className="w-full text-left px-4 py-2.5 rounded-xl bg-muted/50 hover:bg-primary/8 hover:text-primary text-sm transition-colors">
                {q}
              </button>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

/* ====== LOGIN ====== */
function LoginPanel() {
  const { user, login, logout } = useAuth();
  const { close } = usePanel();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!form.email || !form.password) { setError("Please fill in all fields."); return; }
    if (mode === "register" && !form.name) { setError("Please enter your name."); return; }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    login({ name: form.name || form.email.split("@")[0], email: form.email });
    setLoading(false);
    setTimeout(close, 500);
  };

  if (user) {
    return (
      <>
        <PanelHeader icon={User} title="My Account" />
        <div className="flex-1 flex flex-col items-center justify-center p-8 gap-6">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-3xl font-serif font-bold text-primary">
              {user.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="text-center">
            <p className="font-serif text-xl font-bold">{user.name}</p>
            <p className="text-sm text-muted-foreground mt-1">{user.email}</p>
          </div>
          <div className="w-full space-y-2">
            {["My Orders", "My Addresses", "Payment Methods", "Account Settings"].map((item) => (
              <button key={item} className="w-full text-left px-4 py-3 rounded-xl hover:bg-muted text-sm font-medium transition-colors flex items-center justify-between">
                {item} <span className="text-muted-foreground">›</span>
              </button>
            ))}
          </div>
          <button onClick={logout} data-testid="btn-logout"
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-destructive transition-colors mt-2">
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <PanelHeader icon={User} title={mode === "login" ? "Sign In" : "Create Account"} />
      <div className="flex-1 overflow-y-auto p-6">
        <div className="flex gap-2 mb-6 p-1 bg-muted rounded-xl">
          <button onClick={() => setMode("login")} data-testid="btn-tab-login"
            className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${mode === "login" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"}`}>
            <LogIn size={14} className="inline mr-1.5" />Sign In
          </button>
          <button onClick={() => setMode("register")} data-testid="btn-tab-register"
            className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${mode === "register" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"}`}>
            <UserPlus size={14} className="inline mr-1.5" />Register
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-login">
          {mode === "register" && (
            <div>
              <label className="block text-sm font-medium mb-1.5">Full Name</label>
              <input type="text" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Your name" data-testid="input-name"
                className="w-full px-4 py-3 rounded-xl border border-border bg-muted/40 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all" />
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1.5">Email Address</label>
            <input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              placeholder="you@example.com" data-testid="input-email"
              className="w-full px-4 py-3 rounded-xl border border-border bg-muted/40 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Password</label>
            <input type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
              placeholder="••••••••" data-testid="input-password"
              className="w-full px-4 py-3 rounded-xl border border-border bg-muted/40 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all" />
          </div>
          {error && <p className="text-sm text-destructive bg-destructive/10 px-3 py-2 rounded-lg">{error}</p>}
          <button type="submit" disabled={loading} data-testid="btn-submit-login"
            className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed">
            {loading ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>
        <div className="mt-6">
          <div className="relative mb-4"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div><span className="relative bg-background px-3 text-xs text-muted-foreground">Or continue with</span></div>
          <div className="grid grid-cols-2 gap-3">
            {["Google", "Facebook"].map((p) => (
              <button key={p} className="py-2.5 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors">
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

/* ====== WISHLIST ====== */
function WishlistPanel() {
  const wishlist = useWishlist();
  const { add } = useCart();
  return (
    <>
      <PanelHeader icon={Heart} title={`Wishlist (${wishlist.items.length})`} />
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {wishlist.items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
            <Heart size={48} className="text-muted-foreground/40" />
            <div>
              <p className="font-serif text-lg font-semibold">Your wishlist is empty</p>
              <p className="text-sm text-muted-foreground mt-1">Save books you love for later</p>
            </div>
          </div>
        ) : (
          wishlist.items.map((book) => (
            <div key={book.key} className="flex gap-3 p-3 bg-muted/40 rounded-xl" data-testid={`wishlist-item-${book.workKey}`}>
              <Link href={`/book/${book.workKey}`} className="shrink-0">
                <img src={book.coverUrl} alt={book.title}
                  className="w-14 h-20 object-cover rounded-lg shadow-sm"
                  onError={(e) => { (e.target as HTMLImageElement).src = `https://placehold.co/200x300/6B1B1B/FAF8F5?text=Book`; }} />
              </Link>
              <div className="flex-1 min-w-0">
                <Link href={`/book/${book.workKey}`}>
                  <p className="font-serif font-semibold text-sm leading-tight line-clamp-2 hover:text-primary">{book.title}</p>
                </Link>
                <p className="text-xs text-muted-foreground mt-0.5 mb-2">{book.author}</p>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-primary text-sm">${book.price}</span>
                  <button onClick={() => add(book)} data-testid={`btn-wishlist-add-cart-${book.workKey}`}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors">
                    <ShoppingCart size={11} /> Add to Cart
                  </button>
                  <button onClick={() => wishlist.toggle(book)} data-testid={`btn-wishlist-remove-${book.workKey}`}
                    className="p-1 text-muted-foreground hover:text-destructive transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {wishlist.items.length > 0 && (
        <div className="p-5 border-t border-border shrink-0">
          <button onClick={() => wishlist.items.forEach((b) => add(b))}
            className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all shadow-md"
            data-testid="btn-add-all-to-cart">
            Add All to Cart
          </button>
        </div>
      )}
    </>
  );
}
