import { createContext, useContext, useReducer, type ReactNode } from "react";
import type { Book } from "./api";

export interface CartItem extends Book {
  qty: number;
}

export type PanelType = "cart" | "search" | "login" | "wishlist" | null;

interface State {
  cart: CartItem[];
  wishlist: Book[];
  panel: PanelType;
  user: { name: string; email: string } | null;
}

type Action =
  | { type: "ADD_TO_CART"; book: Book }
  | { type: "REMOVE_FROM_CART"; key: string }
  | { type: "UPDATE_QTY"; key: string; qty: number }
  | { type: "TOGGLE_WISHLIST"; book: Book }
  | { type: "OPEN_PANEL"; panel: PanelType }
  | { type: "CLOSE_PANEL" }
  | { type: "LOGIN"; user: { name: string; email: string } }
  | { type: "LOGOUT" };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "ADD_TO_CART": {
      const existing = state.cart.find((i) => i.key === action.book.key);
      if (existing) {
        return { ...state, cart: state.cart.map((i) => i.key === action.book.key ? { ...i, qty: i.qty + 1 } : i) };
      }
      return { ...state, cart: [...state.cart, { ...action.book, qty: 1 }] };
    }
    case "REMOVE_FROM_CART":
      return { ...state, cart: state.cart.filter((i) => i.key !== action.key) };
    case "UPDATE_QTY":
      if (action.qty <= 0) return { ...state, cart: state.cart.filter((i) => i.key !== action.key) };
      return { ...state, cart: state.cart.map((i) => i.key === action.key ? { ...i, qty: action.qty } : i) };
    case "TOGGLE_WISHLIST": {
      const exists = state.wishlist.find((b) => b.key === action.book.key);
      return { ...state, wishlist: exists ? state.wishlist.filter((b) => b.key !== action.book.key) : [...state.wishlist, action.book] };
    }
    case "OPEN_PANEL": return { ...state, panel: action.panel };
    case "CLOSE_PANEL": return { ...state, panel: null };
    case "LOGIN": return { ...state, user: action.user };
    case "LOGOUT": return { ...state, user: null };
    default: return state;
  }
}

const Ctx = createContext<{ state: State; dispatch: React.Dispatch<Action> } | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { cart: [], wishlist: [], panel: null, user: null });
  return <Ctx.Provider value={{ state, dispatch }}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be inside StoreProvider");
  return ctx;
}

export function useCart() {
  const { state, dispatch } = useStore();
  const total = state.cart.reduce((acc, i) => acc + i.price * i.qty, 0);
  const count = state.cart.reduce((acc, i) => acc + i.qty, 0);
  return {
    items: state.cart,
    total,
    count,
    add: (book: Book) => dispatch({ type: "ADD_TO_CART", book }),
    remove: (key: string) => dispatch({ type: "REMOVE_FROM_CART", key }),
    updateQty: (key: string, qty: number) => dispatch({ type: "UPDATE_QTY", key, qty }),
  };
}

export function useWishlist() {
  const { state, dispatch } = useStore();
  return {
    items: state.wishlist,
    toggle: (book: Book) => dispatch({ type: "TOGGLE_WISHLIST", book }),
    has: (key: string) => state.wishlist.some((b) => b.key === key),
  };
}

export function usePanel() {
  const { state, dispatch } = useStore();
  return {
    panel: state.panel,
    open: (panel: PanelType) => dispatch({ type: "OPEN_PANEL", panel }),
    close: () => dispatch({ type: "CLOSE_PANEL" }),
  };
}

export function useAuth() {
  const { state, dispatch } = useStore();
  return {
    user: state.user,
    login: (user: { name: string; email: string }) => dispatch({ type: "LOGIN", user }),
    logout: () => dispatch({ type: "LOGOUT" }),
  };
}
