export interface OLBook {
  key: string;
  title: string;
  author_name?: string[];
  cover_i?: number;
  first_publish_year?: number;
  subject?: string[];
  edition_count?: number;
  ratings_average?: number;
  ratings_count?: number;
  ia?: string[];
  number_of_pages_median?: number;
  publisher?: string[];
  language?: string[];
  description?: string;
}

export interface OLSearchResponse {
  docs: OLBook[];
  numFound: number;
  start: number;
}

export interface OLWorkDetail {
  key: string;
  title: string;
  description?: string | { value: string };
  subjects?: string[];
  subject_places?: string[];
  subject_times?: string[];
  covers?: number[];
  authors?: { author: { key: string } }[];
  first_publish_date?: string;
  excerpts?: { excerpt: string; comment?: string }[];
}

export interface Book {
  key: string;
  workKey: string;
  title: string;
  author: string;
  coverId?: number;
  coverUrl: string;
  year?: number;
  subjects?: string[];
  rating: number;
  ratingCount: number;
  pages?: number;
  publishers?: string[];
  price: number;
  originalPrice: number;
  badge?: string;
}

const BASE = "https://openlibrary.org";
const COVERS = "https://covers.openlibrary.org/b/id";

function deterministic(key: string, min: number, max: number): number {
  let hash = 0;
  for (let i = 0; i < key.length; i++) {
    hash = (hash * 31 + key.charCodeAt(i)) & 0xffffffff;
  }
  return min + (Math.abs(hash) % (max - min + 1));
}

function mapBook(doc: OLBook, badge?: string): Book {
  const workKey = doc.key.replace("/works/", "");
  const price = deterministic(doc.key, 12, 65);
  const originalPrice = deterministic(doc.key + "orig", price + 5, price + 25);
  return {
    key: doc.key,
    workKey,
    title: doc.title,
    author: doc.author_name?.[0] ?? "Unknown Author",
    coverId: doc.cover_i,
    coverUrl: doc.cover_i
      ? `${COVERS}/${doc.cover_i}-L.jpg`
      : `https://placehold.co/200x300/6B1B1B/FAF8F5?text=${encodeURIComponent(doc.title.slice(0, 20))}`,
    year: doc.first_publish_year,
    subjects: doc.subject?.slice(0, 6),
    rating: doc.ratings_average ?? deterministic(doc.key + "r", 35, 50) / 10,
    ratingCount: doc.ratings_count ?? deterministic(doc.key + "rc", 50, 5000),
    pages: doc.number_of_pages_median,
    publishers: doc.publisher?.slice(0, 2),
    price,
    originalPrice,
    badge,
  };
}

export async function searchBooks(query: string, limit = 20): Promise<Book[]> {
  try {
    const r = await fetch(
      `${BASE}/search.json?q=${encodeURIComponent(query)}&limit=${limit}&fields=key,title,author_name,cover_i,first_publish_year,subject,ratings_average,ratings_count,number_of_pages_median,publisher`
    );
    if (!r.ok) throw new Error("fetch failed");
    const data: OLSearchResponse = await r.json();
    return data.docs.map((d) => mapBook(d));
  } catch {
    return [];
  }
}

export async function getBooksBySubject(subject: string, limit = 16): Promise<Book[]> {
  try {
    const r = await fetch(
      `${BASE}/search.json?subject=${encodeURIComponent(subject)}&limit=${limit}&sort=rating&fields=key,title,author_name,cover_i,first_publish_year,subject,ratings_average,ratings_count,number_of_pages_median,publisher`
    );
    if (!r.ok) throw new Error();
    const data: OLSearchResponse = await r.json();
    return data.docs.filter((d) => d.cover_i).map((d) => mapBook(d));
  } catch {
    return [];
  }
}

export async function getTrendingBooks(limit = 20): Promise<Book[]> {
  try {
    const r = await fetch(
      `${BASE}/search.json?q=fiction&sort=rating+desc&limit=${limit}&fields=key,title,author_name,cover_i,first_publish_year,subject,ratings_average,ratings_count,number_of_pages_median,publisher`
    );
    if (!r.ok) throw new Error();
    const data: OLSearchResponse = await r.json();
    return data.docs.filter((d) => d.cover_i).slice(0, limit).map((d, i) =>
      mapBook(d, i < 3 ? "Bestseller" : i < 6 ? "New" : undefined)
    );
  } catch {
    return [];
  }
}

export async function getNewArrivals(limit = 16): Promise<Book[]> {
  try {
    const r = await fetch(
      `${BASE}/search.json?q=novel&sort=new&limit=${limit}&fields=key,title,author_name,cover_i,first_publish_year,subject,ratings_average,ratings_count,number_of_pages_median,publisher`
    );
    if (!r.ok) throw new Error();
    const data: OLSearchResponse = await r.json();
    return data.docs.filter((d) => d.cover_i).map((d) => mapBook(d, "New Arrival"));
  } catch {
    return [];
  }
}

export async function getBookDetail(workKey: string): Promise<{ book: Book | null; detail: OLWorkDetail | null }> {
  try {
    const [workRes, searchRes] = await Promise.all([
      fetch(`${BASE}/works/${workKey}.json`),
      fetch(
        `${BASE}/search.json?q=key:/works/${workKey}&fields=key,title,author_name,cover_i,first_publish_year,subject,ratings_average,ratings_count,number_of_pages_median,publisher,edition_count`
      ),
    ]);
    const detail: OLWorkDetail = await workRes.json();
    const searchData: OLSearchResponse = await searchRes.json();
    const doc = searchData.docs[0];
    if (!doc) return { book: null, detail };
    return { book: mapBook(doc), detail };
  } catch {
    return { book: null, detail: null };
  }
}

export async function getRecommended(subjects: string[], excludeKey: string, limit = 8): Promise<Book[]> {
  const subject = subjects[0] ?? "fiction";
  try {
    const books = await getBooksBySubject(subject, 24);
    return books.filter((b) => b.key !== excludeKey).slice(0, limit);
  } catch {
    return [];
  }
}

export function coverUrl(coverId: number, size: "S" | "M" | "L" = "L"): string {
  return `${COVERS}/${coverId}-${size}.jpg`;
}
