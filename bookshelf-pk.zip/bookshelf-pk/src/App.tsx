import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { StoreProvider } from "@/lib/context";
import Navbar from "@/components/Navbar";
import RightPanel from "@/components/RightPanel";
import Chatbot from "@/components/Chatbot";
import Home from "@/pages/Home";
import BookDetail from "@/pages/BookDetail";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 5 * 60 * 1000, retry: 1 } },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/book/:workKey" component={BookDetail} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <StoreProvider>
        <WouterRouter>
          <div className="min-h-screen bg-background text-foreground">
            <Navbar />
            <RightPanel />
            <Router />
            <Chatbot />
          </div>
        </WouterRouter>
      </StoreProvider>
    </QueryClientProvider>
  );
}

export default App;
