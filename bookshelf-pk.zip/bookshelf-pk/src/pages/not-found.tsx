import { Link } from "wouter";
import { BookOpen, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center px-4" data-testid="page-not-found">
      <div className="w-24 h-24 rounded-3xl bg-primary/10 flex items-center justify-center">
        <BookOpen size={40} className="text-primary" />
      </div>
      <div>
        <h1 className="font-serif text-6xl font-bold gradient-text">404</h1>
        <h2 className="font-serif text-2xl font-bold mt-2">Page Not Found</h2>
        <p className="text-muted-foreground mt-2 max-w-sm">
          The page you're looking for doesn't exist, or has been moved. Let's get you back to the books.
        </p>
      </div>
      <Link href="/" data-testid="link-back-home"
        className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl">
        <ArrowLeft size={18} /> Back to BookShelf
      </Link>
    </div>
  );
}
