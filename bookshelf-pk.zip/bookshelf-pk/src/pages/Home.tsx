import { useState, useEffect } from "react";
import { Link } from "wouter";
import { getTrendingBooks, getNewArrivals, getBooksBySubject, type Book } from "@/lib/api";
import Hero from "@/components/Hero";
import BookSection from "@/components/BookSection";
import { usePanel } from "@/lib/context";
import { ArrowRight, BookOpen, Gift, Truck, Shield, RefreshCw } from "lucide-react";

const CATEGORIES = [
  { name: "Fiction", emoji: "📖", color: "from-rose-100 to-rose-50 border-rose-200", subject: "fiction" },
  { name: "Mystery", emoji: "🔍", color: "from-slate-100 to-slate-50 border-slate-200", subject: "mystery" },
  { name: "Romance", emoji: "💌", color: "from-pink-100 to-pink-50 border-pink-200", subject: "romance" },
  { name: "Sci-Fi", emoji: "🚀", color: "from-blue-100 to-blue-50 border-blue-200", subject: "science_fiction" },
  { name: "Biography", emoji: "👤", color: "from-amber-100 to-amber-50 border-amber-200", subject: "biography" },
  { name: "Self-Help", emoji: "🌱", color: "from-green-100 to-green-50 border-green-200", subject: "self-help" },
  { name: "History", emoji: "🏛️", color: "from-yellow-100 to-yellow-50 border-yellow-200", subject: "history" },
  { name: "Children", emoji: "🎈", color: "from-purple-100 to-purple-50 border-purple-200", subject: "children" },
];

const PERKS = [
  { icon: Truck, title: "Free Delivery", desc: "On all orders across Pakistan" },
  { icon: Shield, title: "Secure Payment", desc: "100% secure & encrypted" },
  { icon: RefreshCw, title: "Easy Returns", desc: "7-day hassle-free return" },
  { icon: Gift, title: "Gift Wrapping", desc: "Available on all orders" },
];

const FEATURED_AUTHORS = [
  { name: "Mustansar Hussain Tarar", genre: "Urdu Fiction", books: 45, query: "Mustansar Hussain Tarar" },
  { name: "J.K. Rowling", genre: "Fantasy", books: 14, query: "J.K. Rowling" },
  { name: "James Clear", genre: "Self-Help", books: 5, query: "James Clear Atomic Habits" },
];

export default function Home() {
  const [trending, setTrending] = useState<Book[]>([]);
  const [newArrivals, setNewArrivals] = useState<Book[]>([]);
  const [classicBooks, setClassicBooks] = useState<Book[]>([]);
  const [romanceBooks, setRomanceBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [sectionLoading, setSectionLoading] = useState(true);
  const { open } = usePanel();

  useEffect(() => {
    async function load() {
      const [trend, novel] = await Promise.all([
        getTrendingBooks(20),
        getNewArrivals(16),
      ]);
      setTrending(trend);
      setNewArrivals(novel);
      setLoading(false);
      setSectionLoading(false);

      const [classics, romance] = await Promise.all([
        getBooksBySubject("classic_literature", 16),
        getBooksBySubject("romance", 16),
      ]);
      setClassicBooks(classics);
      setRomanceBooks(romance);
    }
    load();
  }, []);

  return (
    <main className="overflow-x-hidden" data-testid="page-home">
      {/* Hero */}
      <Hero featuredBooks={trending} />

      {/* Perks bar */}
      <div className="bg-primary text-primary-foreground py-4 px-4 md:px-8">
        <div className="max-w-screen-xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {PERKS.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-center gap-3">
              <Icon size={20} className="shrink-0 opacity-80" />
              <div>
                <p className="font-semibold text-sm">{title}</p>
                <p className="text-xs opacity-70">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <section className="py-14 px-4 md:px-8 lg:px-16 xl:px-24 bg-muted/30" data-testid="section-categories">
        <div className="max-w-screen-xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="font-serif text-3xl md:text-4xl font-bold">Browse by Genre</h2>
            <p className="text-muted-foreground mt-2">Find your next obsession in any category</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
            {CATEGORIES.map((cat) => (
              <button key={cat.name}
                onClick={() => open("search")}
                data-testid={`category-${cat.name.toLowerCase()}`}
                className={`group flex flex-col items-center gap-3 p-5 rounded-2xl border bg-gradient-to-br ${cat.color} hover:shadow-md transition-all duration-300 hover:-translate-y-1`}>
                <span className="text-4xl group-hover:scale-110 transition-transform duration-300">{cat.emoji}</span>
                <span className="font-semibold text-sm">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Trending / Bestsellers */}
      <div className="max-w-screen-xl mx-auto">
        <BookSection
          title="Trending Now"
          subtitle="Books everyone's reading this month"
          books={trending}
          loading={loading}
        />
      </div>

      {/* Banner */}
      <section className="mx-4 md:mx-8 lg:mx-16 xl:mx-24 my-8 rounded-3xl overflow-hidden relative"
        style={{ background: "linear-gradient(135deg, #1C2B4A 0%, #2D3F6B 50%, #1C2B4A 100%)" }}
        data-testid="section-banner">
        <div className="absolute inset-0 opacity-20"
          style={{ backgroundImage: "radial-gradient(circle at 80% 50%, #C8960C 0%, transparent 60%)" }} />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between p-8 md:p-12 gap-6">
          <div>
            <span className="text-[var(--bs-gold)] text-sm font-semibold uppercase tracking-wider">Limited Time Offer</span>
            <h3 className="font-serif text-3xl md:text-4xl font-bold text-white mt-2">
              Get 20% Off<br />Your First Order
            </h3>
            <p className="text-white/70 mt-3 max-w-sm">Use code <strong className="text-[var(--bs-gold)]">BOOKSHELF20</strong> at checkout. Valid for new customers only.</p>
          </div>
          <button onClick={() => open("search")} data-testid="btn-banner-cta"
            className="flex items-center gap-2 px-8 py-4 rounded-2xl font-bold text-base shrink-0 transition-all hover:gap-3"
            style={{ background: "var(--bs-gold)", color: "#1C2B4A" }}>
            <BookOpen size={20} /> Shop Now <ArrowRight size={18} />
          </button>
        </div>
      </section>

      {/* New Arrivals */}
      <div className="max-w-screen-xl mx-auto">
        <BookSection
          title="New Arrivals"
          subtitle="Fresh off the press"
          books={newArrivals}
          loading={sectionLoading}
        />
      </div>

      {/* Featured Authors */}
      <section className="py-14 px-4 md:px-8 lg:px-16 xl:px-24 bg-muted/30" data-testid="section-authors">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-serif text-3xl font-bold">Featured Authors</h2>
              <p className="text-muted-foreground mt-1">Discover the writers shaping today's literature</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {FEATURED_AUTHORS.map((author) => (
              <button key={author.name} onClick={() => open("search")}
                data-testid={`author-${author.name.split(" ")[0].toLowerCase()}`}
                className="group flex items-center gap-4 p-5 bg-card rounded-2xl border border-border hover:border-primary/30 hover:shadow-lg transition-all duration-300 text-left">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <span className="font-serif text-2xl font-bold text-primary">{author.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="font-serif font-bold leading-tight">{author.name}</p>
                  <p className="text-sm text-muted-foreground mt-0.5">{author.genre}</p>
                  <p className="text-xs text-primary font-medium mt-1">{author.books} books available</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Classics */}
      <div className="max-w-screen-xl mx-auto">
        <BookSection
          title="Classic Literature"
          subtitle="Timeless stories that never grow old"
          books={classicBooks}
          loading={sectionLoading}
        />
      </div>

      {/* Romance */}
      <div className="max-w-screen-xl mx-auto">
        <BookSection
          title="Romance & Drama"
          subtitle="Stories of love, loss, and everything in between"
          books={romanceBooks}
          loading={sectionLoading}
        />
      </div>

      {/* Newsletter */}
      <section className="py-16 px-4 md:px-8 lg:px-16 xl:px-24 bg-card border-t border-border" data-testid="section-newsletter">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-serif text-3xl font-bold mb-3">Stay in the Loop</h2>
          <p className="text-muted-foreground mb-6">Get new arrivals, reading tips, and exclusive deals delivered to your inbox.</p>
          <div className="flex gap-3 max-w-md mx-auto">
            <input type="email" placeholder="your@email.com" data-testid="input-newsletter"
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm transition-all" />
            <button data-testid="btn-newsletter-submit"
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-all shadow-md hover:shadow-lg shrink-0">
              Subscribe
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-3">No spam, ever. Unsubscribe anytime.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1C2B4A] text-white py-12 px-4 md:px-8 lg:px-16 xl:px-24" data-testid="footer">
        <div className="max-w-screen-xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <BookOpen size={22} className="text-[var(--bs-gold)]" />
              <span className="font-serif text-xl font-bold">BookShelf.pk</span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed">Pakistan's premier online bookstore. Bringing stories to every reader since 2020.</p>
          </div>
          {[
            { title: "Quick Links", links: ["Home", "New Arrivals", "Bestsellers", "About Us", "Contact"] },
            { title: "Categories", links: ["Fiction", "Non-Fiction", "Academic", "Children", "Urdu Literature"] },
            { title: "Support", links: ["Track Order", "Returns", "FAQs", "Shipping Info", "Privacy Policy"] },
          ].map((col) => (
            <div key={col.title}>
              <h4 className="font-semibold text-sm uppercase tracking-wider text-[var(--bs-gold)] mb-4">{col.title}</h4>
              <ul className="space-y-2">
                {col.links.map((link) => (
                  <li key={link}>
                    <button onClick={() => {}} className="text-white/60 text-sm hover:text-white transition-colors">{link}</button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="max-w-screen-xl mx-auto mt-10 pt-6 border-t border-white/10 text-center text-white/40 text-sm">
          © {new Date().getFullYear()} BookShelf.pk — All rights reserved. Made with ❤️ in Pakistan.
        </div>
      </footer>
    </main>
  );
}
