import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { Star, Heart, ShoppingCart, ArrowLeft, BookOpen, Truck, Shield, Share2, ChevronDown, ChevronUp } from "lucide-react";
import { motion } from "framer-motion";
import { getBookDetail, getRecommended, type Book } from "@/lib/api";
import { useCart, useWishlist } from "@/lib/context";
import BookCard from "@/components/BookCard";

const REVIEW_DATA = [
  { name: "Aisha K.", rating: 5, date: "2 weeks ago", text: "Absolutely loved this book! The writing style is captivating and I couldn't put it down. Highly recommend to everyone." },
  { name: "Muhammad R.", rating: 4, date: "1 month ago", text: "A wonderful read. The story kept me engaged throughout. Great addition to my personal library." },
  { name: "Sara L.", rating: 5, date: "3 months ago", text: "One of the best books I've read this year. The characters are so well developed and the plot is masterfully crafted." },
];

export default function BookDetail() {
  const [, params] = useRoute("/book/:workKey");
  const workKey = params?.workKey ?? "";
  const [book, setBook] = useState<Book | null>(null);
  const [desc, setDesc] = useState<string>("");
  const [recommended, setRecommended] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [imgErr, setImgErr] = useState(false);
  const [qty, setQty] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);
  const [descExpanded, setDescExpanded] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<"hardcover" | "paperback" | "ebook">("paperback");
  const { add } = useCart();
  const wishlist = useWishlist();

  useEffect(() => {
    setLoading(true);
    setBook(null);
    setImgErr(false);
    setDesc("");
    setRecommended([]);

    async function load() {
      if (!workKey) return;
      const { book: b, detail } = await getBookDetail(workKey);
      setBook(b);

      if (detail?.description) {
        if (typeof detail.description === "string") setDesc(detail.description);
        else if (detail.description.value) setDesc(detail.description.value);
      }

      setLoading(false);

      if (b?.subjects?.length) {
        const recs = await getRecommended(b.subjects, b.key);
        setRecommended(recs);
      }
    }
    load();
  }, [workKey]);

  const handleAddToCart = () => {
    if (!book) return;
    for (let i = 0; i < qty; i++) add(book);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const isWishlisted = book ? wishlist.has(book.key) : false;

  const priceByFormat = {
    hardcover: book ? book.originalPrice : 0,
    paperback: book ? book.price : 0,
    ebook: book ? Math.round(book.price * 0.6) : 0,
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-20 px-4 md:px-8 lg:px-16 xl:px-24 max-w-screen-xl mx-auto" data-testid="page-book-detail-loading">
        <div className="flex flex-col md:flex-row gap-10 mt-10">
          <div className="skeleton w-64 md:w-72 shrink-0" style={{ aspectRatio: "2/3", borderRadius: "1.5rem" }} />
          <div className="flex-1 space-y-4 pt-4">
            <div className="skeleton h-10 rounded-xl w-3/4" />
            <div className="skeleton h-5 rounded-xl w-1/2" />
            <div className="skeleton h-4 rounded w-1/4" />
            <div className="space-y-2 mt-6">
              {[1, 2, 3, 4].map((i) => <div key={i} className="skeleton h-4 rounded w-full" />)}
            </div>
            <div className="skeleton h-12 rounded-2xl w-48 mt-8" />
          </div>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen pt-28 flex flex-col items-center justify-center gap-4" data-testid="page-book-not-found">
        <BookOpen size={48} className="text-muted-foreground/40" />
        <h2 className="font-serif text-2xl font-bold">Book not found</h2>
        <p className="text-muted-foreground">This book may have been removed or the link is invalid.</p>
        <Link href="/" className="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors">
          <ArrowLeft size={18} /> Back to Home
        </Link>
      </div>
    );
  }

  const displayPrice = priceByFormat[selectedFormat];
  const discount = Math.round(((book.originalPrice - displayPrice) / book.originalPrice) * 100);
  const coverSrc = imgErr
    ? `https://placehold.co/300x450/6B1B1B/FAF8F5?text=${encodeURIComponent(book.title.slice(0, 18))}`
    : book.coverUrl;

  return (
    <main className="min-h-screen pt-20 pb-16 overflow-x-hidden" data-testid="page-book-detail">
      {/* Breadcrumb */}
      <div className="px-4 md:px-8 lg:px-16 xl:px-24 max-w-screen-xl mx-auto py-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Link href="/" className="hover:text-primary transition-colors">Home</Link>
          <span>/</span>
          <span className="truncate max-w-xs text-foreground">{book.title}</span>
        </div>
      </div>

      {/* Main content */}
      <div className="px-4 md:px-8 lg:px-16 xl:px-24 max-w-screen-xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col lg:flex-row gap-10"
        >
          {/* Cover image */}
          <div className="shrink-0 flex flex-col items-center lg:items-start gap-4">
            <div className="relative group">
              <div className="w-64 md:w-72 rounded-3xl overflow-hidden shadow-2xl" style={{ aspectRatio: "2/3" }}>
                <img
                  src={coverSrc}
                  alt={book.title}
                  onError={() => setImgErr(true)}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  data-testid="img-book-cover"
                />
              </div>
              {book.badge && (
                <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold shadow">
                  {book.badge}
                </span>
              )}
              {discount > 0 && (
                <span className="absolute top-4 right-4 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-bold shadow">
                  -{discount}%
                </span>
              )}
            </div>

            {/* Action buttons under cover */}
            <div className="flex gap-2 w-full max-w-[288px]">
              <button
                onClick={() => book && wishlist.toggle(book)}
                data-testid="btn-detail-wishlist"
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 text-sm font-semibold transition-all duration-200 ${isWishlisted ? "border-rose-400 bg-rose-50 text-rose-500" : "border-border hover:border-rose-300 hover:text-rose-500"}`}>
                <Heart size={16} fill={isWishlisted ? "currentColor" : "none"} />
                {isWishlisted ? "Saved" : "Wishlist"}
              </button>
              <button
                onClick={() => navigator.share?.({ title: book.title, url: window.location.href })}
                data-testid="btn-detail-share"
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border-2 border-border text-sm font-semibold hover:border-primary hover:text-primary transition-all">
                <Share2 size={16} /> Share
              </button>
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0">
            {/* Title & author */}
            <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold leading-tight" data-testid="text-book-title">
              {book.title}
            </h1>
            <p className="text-lg text-muted-foreground mt-2 font-medium" data-testid="text-book-author">
              by {book.author}
            </p>

            {/* Rating */}
            <div className="flex items-center gap-3 mt-4">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} size={16}
                    className={s <= Math.round(book.rating) ? "fill-amber-400 text-amber-400" : "text-gray-300 fill-gray-200"} />
                ))}
              </div>
              <span className="font-semibold">{book.rating.toFixed(1)}</span>
              <span className="text-muted-foreground text-sm">({book.ratingCount.toLocaleString()} reviews)</span>
            </div>

            {/* Format selector */}
            <div className="mt-6">
              <p className="text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wider">Format</p>
              <div className="flex gap-3">
                {(["paperback", "hardcover", "ebook"] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setSelectedFormat(fmt)}
                    data-testid={`btn-format-${fmt}`}
                    className={`px-4 py-2.5 rounded-xl border-2 text-sm font-semibold transition-all capitalize ${selectedFormat === fmt ? "border-primary bg-primary/8 text-primary" : "border-border hover:border-primary/40"}`}>
                    {fmt}
                    <span className="block text-xs font-normal text-muted-foreground">${priceByFormat[fmt]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Price */}
            <div className="mt-6 flex items-baseline gap-3">
              <span className="text-4xl font-bold text-primary" data-testid="text-book-price">${displayPrice}</span>
              <span className="text-xl text-muted-foreground line-through">${book.originalPrice}</span>
              {discount > 0 && (
                <span className="px-2 py-0.5 rounded-lg bg-green-100 text-green-700 text-sm font-semibold">
                  Save {discount}%
                </span>
              )}
            </div>

            {/* Stock & shipping */}
            <div className="flex items-center gap-4 mt-4 text-sm">
              <span className="flex items-center gap-1.5 text-green-600 font-medium">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                In Stock
              </span>
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <Truck size={14} /> Free Delivery
              </span>
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <Shield size={14} /> Secure Payment
              </span>
            </div>

            {/* Qty + Add to cart */}
            <div className="flex flex-wrap items-center gap-3 mt-8">
              <div className="flex items-center border-2 border-border rounded-xl overflow-hidden">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} data-testid="btn-qty-dec"
                  className="px-4 py-3 hover:bg-muted transition-colors text-lg font-medium">−</button>
                <span className="px-5 py-3 font-semibold text-lg min-w-[56px] text-center" data-testid="text-qty">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} data-testid="btn-qty-inc"
                  className="px-4 py-3 hover:bg-muted transition-colors text-lg font-medium">+</button>
              </div>

              <button
                onClick={handleAddToCart}
                data-testid="btn-add-to-cart"
                className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl font-bold text-base transition-all duration-300 shadow-lg hover:shadow-xl ${addedToCart ? "bg-green-500 text-white scale-95" : "bg-primary text-primary-foreground hover:bg-primary/90"}`}>
                <ShoppingCart size={20} />
                {addedToCart ? "Added to Cart!" : "Add to Cart"}
              </button>

              <button
                data-testid="btn-buy-now"
                className="flex-1 md:flex-none px-8 py-3.5 rounded-2xl font-bold text-base border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300">
                Buy Now
              </button>
            </div>

            {/* Book info grid */}
            <div className="mt-8 grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { label: "Publisher", value: book.publishers?.[0] ?? "Unknown" },
                { label: "Year", value: book.year ?? "N/A" },
                { label: "Pages", value: book.pages ? `${book.pages} pages` : "N/A" },
                { label: "Language", value: "English" },
                { label: "Format", value: selectedFormat.charAt(0).toUpperCase() + selectedFormat.slice(1) },
                { label: "Genre", value: book.subjects?.[0] ?? "General" },
              ].map(({ label, value }) => (
                <div key={label} className="p-3 bg-muted/50 rounded-xl">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
                  <p className="font-medium text-sm mt-0.5 truncate">{String(value)}</p>
                </div>
              ))}
            </div>

            {/* Description */}
            {desc && (
              <div className="mt-8">
                <h3 className="font-serif text-xl font-bold mb-3">About this Book</h3>
                <div className={`text-muted-foreground leading-relaxed text-sm relative ${!descExpanded ? "max-h-32 overflow-hidden" : ""}`}>
                  <p>{desc}</p>
                  {!descExpanded && (
                    <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-background to-transparent" />
                  )}
                </div>
                <button
                  onClick={() => setDescExpanded((v) => !v)}
                  data-testid="btn-expand-desc"
                  className="flex items-center gap-1.5 text-primary text-sm font-semibold mt-2 hover:underline">
                  {descExpanded ? <><ChevronUp size={16} /> Show less</> : <><ChevronDown size={16} /> Read more</>}
                </button>
              </div>
            )}

            {/* Subjects */}
            {book.subjects && book.subjects.length > 0 && (
              <div className="mt-6">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Tags</p>
                <div className="flex flex-wrap gap-2">
                  {book.subjects.slice(0, 10).map((s) => (
                    <span key={s} className="px-3 py-1 rounded-full bg-muted text-xs font-medium hover:bg-primary/10 hover:text-primary transition-colors cursor-pointer">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Reviews */}
        <section className="mt-16 pt-10 border-t border-border" data-testid="section-reviews">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-2xl md:text-3xl font-bold">Customer Reviews</h2>
            <button className="px-5 py-2.5 rounded-xl border border-border text-sm font-semibold hover:bg-muted transition-colors">
              Write a Review
            </button>
          </div>

          {/* Rating summary */}
          <div className="flex flex-col md:flex-row gap-8 mb-8 p-6 bg-muted/30 rounded-2xl">
            <div className="text-center shrink-0">
              <p className="text-6xl font-bold font-serif text-primary">{book.rating.toFixed(1)}</p>
              <div className="flex justify-center gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} size={18} className={s <= Math.round(book.rating) ? "fill-amber-400 text-amber-400" : "fill-gray-200 text-gray-200"} />
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-1">{book.ratingCount.toLocaleString()} ratings</p>
            </div>
            <div className="flex-1 space-y-2">
              {[5, 4, 3, 2, 1].map((star) => {
                const pct = star === 5 ? 62 : star === 4 ? 22 : star === 3 ? 10 : star === 2 ? 4 : 2;
                return (
                  <div key={star} className="flex items-center gap-3 text-sm">
                    <span className="w-12 text-right shrink-0">{star} star</span>
                    <div className="flex-1 h-2.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-8 text-muted-foreground shrink-0">{pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Review list */}
          <div className="space-y-5">
            {REVIEW_DATA.map((review, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="p-5 bg-card border border-border rounded-2xl"
                data-testid={`review-item-${i}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-serif font-bold text-primary">
                      {review.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{review.name}</p>
                      <p className="text-xs text-muted-foreground">{review.date}</p>
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} size={13} className={s <= review.rating ? "fill-amber-400 text-amber-400" : "fill-gray-200 text-gray-200"} />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{review.text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Recommended */}
        {recommended.length > 0 && (
          <section className="mt-16 pt-10 border-t border-border" data-testid="section-recommended">
            <h2 className="font-serif text-2xl md:text-3xl font-bold mb-8">Readers Also Enjoyed</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {recommended.slice(0, 6).map((rec) => (
                <BookCard key={rec.key} book={rec} />
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
